// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "Rt2AVIBPLibrary.h"
#include "Rt2AVI.h"
#include "Engine/TextureRenderTarget2D.h"


RunableAvi*  URt2AVIBPLibrary::AviSaver = NULL;
UTextureRenderTarget2D* URt2AVIBPLibrary::targetTex = NULL;
FString URt2AVIBPLibrary::pathName("rt2avi");
URt2AVIBPLibrary::URt2AVIBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

FString URt2AVIBPLibrary::Rt2AVIStartVideo(UTextureRenderTarget2D* Param)
{
	
	if (AviSaver)
	{
		AviSaver->b_runing = false;
	}
	AviSaver = NULL;
	targetTex = NULL;

	if (!Param)
	{
		return "";
	}
	targetTex = Param;
	FString Timestamp = FString::Printf(TEXT("%s.avi"), *FDateTime::Now().ToString());
	FString OutputDir(FPaths::ProjectDir() / pathName);
	FString OutputFilename = OutputDir / Timestamp;
	FPaths::NormalizeFilename(OutputFilename);
	AviSaver = new RunableAvi(OutputFilename, Param->SizeX, Param->SizeY);

	return OutputFilename;
}

void URt2AVIBPLibrary::SetRt2AviPath(FString path)
{
	FString tmppath = path.Trim();
	if (!tmppath.IsEmpty())
	{
		pathName = path;
	}
}

void URt2AVIBPLibrary::Rt2AVIEndVideo()
{
	if (AviSaver)
	{
		AviSaver->b_runing = false;
	}
	AviSaver = NULL;
	targetTex = NULL;
}

void URt2AVIBPLibrary::Rt2AVICaptureFrame()
{
	if (targetTex && AviSaver && AviSaver->b_runing)
	{
		TSharedPtr<TArray<FColor>, ESPMode::ThreadSafe> OutData = MakeShareable(new TArray<FColor>());
		TArray<FColor> ;
		FRenderTarget* RenderTarget = targetTex->GameThread_GetRenderTargetResource();
		RenderTarget->ReadPixels(*OutData);
		AviSaver->colorbufs.Enqueue(OutData);
	}
}