// Fill out your copyright notice in the Description page of Project Settings.
#include "RunableAvi.h"
#include "AVIWriter.h"
#include "HAL/PlatformProcess.h"

RunableAvi::RunableAvi(FString FileName, int32 x, int32 y)
:m_FileName(FileName),sizeX(x),sizeY(y),b_runing(false), b_closedT(false)
{
	Thread = FRunnableThread::Create(this, TEXT("avi saver"), 128 * 1024, TPri_AboveNormal, FPlatformAffinity::GetPoolThreadMask());
}

RunableAvi::~RunableAvi()
{
	if (b_runing)
	{
		b_runing = false;
	}
	while (!b_closedT)
	{
		FPlatformProcess::Sleep(1);
	}
}


bool RunableAvi::Init()
{
	return true;
}

uint32 RunableAvi::Run()
{
	b_runing = true;

	FAVIWriterOptions Options;
	Options.OutputFilename = m_FileName;
	Options.CaptureFPS = 30;
	//Options.CodecName = "H264Avc";
	Options.bSynchronizeFrames = false;
	Options.Width =sizeX;
	Options.Height = sizeY;
	Options.CompressionQuality = 0.6;
	TUniquePtr<FAVIWriter> AviWriter = TUniquePtr<FAVIWriter>(FAVIWriter::CreateInstance(Options));
	AviWriter->Initialize();
	while (b_runing)
	{
		TSharedPtr<TArray<FColor>, ESPMode::ThreadSafe> curColor;
		while (colorbufs.Dequeue(curColor))
		{
			AviWriter->Update(0., *curColor);
		}
		FPlatformProcess::Sleep(0.01f);
	}
	AviWriter->Finalize();
	b_closedT = true;
	return 0;
}

void RunableAvi::Stop()
{
}