// Fill out your copyright notice in the Description page of Project Settings.

#pragma once


#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "HAL/ThreadSafeBool.h"
#include "Containers/Queue.h"
/**
 * 
 */
class RunableAvi : public FRunnable
{
public:
	RunableAvi(FString FileName, int32 x, int32 y);
	~RunableAvi();

	// Begin FRunnable interface
	virtual bool Init() override;
	virtual uint32 Run();
	virtual void Stop() override;
	// End FRunnable interface
	FThreadSafeBool b_runing;
	FThreadSafeBool b_closedT;
	TQueue<TSharedPtr<TArray<FColor>, ESPMode::ThreadSafe>> colorbufs;
private:
	// Holds the thread object.
	FRunnableThread * Thread;
	FString m_FileName;
	int32 sizeX;
	int32 sizeY;

};
